int suma = 0;
void setup() {
  // initialize digital pin LED_BUILTIN as an output.
  pinMode(LED_BUILTIN, OUTPUT);
  Serial.begin (9600);
}


void loop() {
  digitalWrite(LED_BUILTIN, HIGH);   // turn the LED on (HIGH is the voltage level)
  Serial.println("Led Encendido  ");
  delay(500);                       // wait for a second
  digitalWrite(LED_BUILTIN, LOW);
  Serial.println("Led Apagado");  
  delay(500); 

  suma = suma + 1;

  if (suma%3 == 0){       // resto de la division suma/2 =0?
    Serial.print("El valor de la variable suma es: ");
    Serial.println(suma); 
  }
  
}
