int boton1=2;
int boton2=3;
int bot1=0;
int bot2=0;
int led1=5;
int led2=6;
int led3=7;
int pote=A0;
int entrada=0;


void setup() {
  Serial.begin(9600);
  pinMode(boton1,INPUT);   //entrada boton 1
  pinMode(boton2,INPUT);   //entrada boton 2
  pinMode(led1,OUTPUT);  //salida led 1
  pinMode(led2,OUTPUT);  //salida led 2
  pinMode(led3,OUTPUT);  //salida led 3
  pinMode(pote, INPUT);

}

void loop() {
  entrada=((analogRead(pote))/4);
  Serial.print(char(12));
  Serial.print(analogRead(pote));
  Serial.print("  ");
  Serial.println(entrada);
  analogWrite(led2, entrada);
//  delay(1000);
//  if (digitalRead(boton1)!=1){
//        digitalWrite(led1, HIGH);
//        //digitalWrite(led2, HIGH);
//        digitalWrite(led3, HIGH);
//        delay(500);
//        digitalWrite(led1, LOW);
//        //digitalWrite(led2, LOW);
//        digitalWrite(led3, LOW);
//        delay(500);
//  }
//  else{
//        digitalWrite(led1, HIGH);
//        //digitalWrite(led2, LOW);
//        digitalWrite(led3, HIGH);
//        delay(500);
//        digitalWrite(led1, LOW);
//        //digitalWrite(led2, HIGH);
//        digitalWrite(led3, LOW);
//        delay(500);
//  }
  
 
}
